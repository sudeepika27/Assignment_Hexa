﻿using System;
using System.Collections.Generic;
using InsuranceManagementSystem.dao;
using InsuranceManagementSystem.entity;

namespace InsuranceManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            var policyService = new InsuranceServiceImpl();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n===== Insurance Policy Management =====");
                Console.WriteLine("1. Create Policy");
                Console.WriteLine("2. View Policy by ID");
                Console.WriteLine("3. View All Policies");
                Console.WriteLine("4. Update Policy");
                Console.WriteLine("5. Delete Policy");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");

                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        var newPolicy = new Policy();
                        Console.Write("Enter Policy ID: ");
                        newPolicy.PolicyId = int.Parse(Console.ReadLine()!);
                        Console.Write("Enter Policy Name: ");
                        newPolicy.PolicyName = Console.ReadLine();
                        Console.Write("Enter Coverage Amount: ");
                        newPolicy.CoverageAmount = decimal.Parse(Console.ReadLine()!);
                        Console.Write("Enter Premium: ");
                        newPolicy.Premium = decimal.Parse(Console.ReadLine()!);

                        bool created = policyService.CreatePolicy(newPolicy);
                        Console.WriteLine(created ? "Policy created successfully!" : "Failed to create policy.");
                        break;

                    case "2":
                        Console.Write("Enter Policy ID to view: ");
                        int viewId = int.Parse(Console.ReadLine()!);
                        var policy = policyService.GetPolicy(viewId);
                        if (policy != null)
                        {
                            Console.WriteLine($"ID: {policy.PolicyId}, Name: {policy.PolicyName}, Coverage: {policy.CoverageAmount}, Premium: {policy.Premium}");
                        }
                        else
                        {
                            Console.WriteLine("Policy not found.");
                        }
                        break;

                    case "3":
                        ICollection<Policy> allPolicies = policyService.GetAllPolicies();
                        foreach (var p in allPolicies)
                        {
                            Console.WriteLine($"ID: {p.PolicyId}, Name: {p.PolicyName}, Coverage: {p.CoverageAmount}, Premium: {p.Premium}");
                        }
                        break;

                    case "4":
                        var updatePolicy = new Policy();
                        Console.Write("Enter Policy ID to update: ");
                        updatePolicy.PolicyId = int.Parse(Console.ReadLine()!);
                        Console.Write("Enter new Policy Name: ");
                        updatePolicy.PolicyName = Console.ReadLine();
                        Console.Write("Enter new Coverage Amount: ");
                        updatePolicy.CoverageAmount = decimal.Parse(Console.ReadLine()!);
                        Console.Write("Enter new Premium: ");
                        updatePolicy.Premium = decimal.Parse(Console.ReadLine()!);

                        bool updated = policyService.UpdatePolicy(updatePolicy);
                        Console.WriteLine(updated ? "Policy updated successfully!" : "Failed to update policy.");
                        break;

                    case "5":
                        Console.Write("Enter Policy ID to delete: ");
                        int deleteId = int.Parse(Console.ReadLine()!);
                        bool deleted = policyService.DeletePolicy(deleteId);
                        Console.WriteLine(deleted ? "Policy deleted successfully!" : "Failed to delete policy.");
                        break;

                    case "6":
                        exit = true;
                        Console.WriteLine("Exiting... Goodbye!");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
    }
}
