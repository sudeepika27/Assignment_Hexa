﻿using System;

namespace InsuranceManagementSystem.MyExceptions
{
    public class PolicyNotFoundException : Exception
    {
        public PolicyNotFoundException() : base("Policy not found.") { }

        public PolicyNotFoundException(string message) : base(message) { }

        public PolicyNotFoundException(string message, Exception inner) : base(message, inner) { }
    }
}
