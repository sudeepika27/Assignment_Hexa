﻿namespace InsuranceManagementSystem.entity
{
    public class Policy
    {
        public int PolicyId { get; set; }
        public string? PolicyName { get; set; }
        public decimal CoverageAmount { get; set; }
        public decimal Premium { get; set; }
        public int Term { get; set; }

        public Policy() { }

        public Policy(int policyId, string policyName, decimal coverageAmount, decimal premium, int term)
        {
            PolicyId = policyId;
            PolicyName = policyName;
            CoverageAmount = coverageAmount;
            Premium = premium;
            Term = term;
        }

        public override string ToString()
        {
            return $"PolicyId: {PolicyId}, Name: {PolicyName}, Coverage: {CoverageAmount}, Premium: {Premium}, Term: {Term}";
        }
    }
}
