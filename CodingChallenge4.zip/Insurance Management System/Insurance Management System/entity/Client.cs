﻿namespace InsuranceManagementSystem.entity
{
    public class Client
    {
        public int ClientId { get; set; }
        public string? ClientName { get; set; }
        public string? ContactInfo { get; set; }
        public Policy? Policy { get; set; }

        public Client() { }

        public Client(int clientId, string clientName, string contactInfo, Policy policy)
        {
            ClientId = clientId;
            ClientName = clientName;
            ContactInfo = contactInfo;
            Policy = policy;
        }

        public override string ToString()
        {
            return $"ClientId: {ClientId}, Name: {ClientName}, Contact: {ContactInfo}, Policy: [{Policy}]";
        }
    }
}
