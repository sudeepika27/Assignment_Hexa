﻿using System;
using System.Collections.Generic;
using System.IO;

namespace InsuranceManagementSystem.util
{
    public class DBPropertyUtil
    {
       
            public static string GetConnectionString()
            {
                return "Server=DESKTOP-TTFB49L;Database=IMSDB;Integrated Security=True;TrustServerCertificate=True";
            }
        }
    }

       