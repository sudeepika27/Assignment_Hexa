﻿// Interface: IPolicyService.cs
using System.Collections.Generic;
using InsuranceManagementSystem.entity;

namespace InsuranceManagementSystem.dao
{
    public interface IPolicyService
    {
        bool CreatePolicy(Policy policy);
        Policy GetPolicy(int policyId);
        ICollection<Policy> GetAllPolicies();

        bool UpdatePolicy(Policy policy);
        bool DeletePolicy(int policyId);
    }
}
