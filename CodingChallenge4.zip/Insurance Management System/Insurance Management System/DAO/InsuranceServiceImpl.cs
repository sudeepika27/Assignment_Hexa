﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using InsuranceManagementSystem.entity;
using InsuranceManagementSystem.util;

namespace InsuranceManagementSystem.dao
{
    public class InsuranceServiceImpl : IPolicyService
    {
        private SqlConnection connection;

        public InsuranceServiceImpl()
        {
            // Establish connection using Connection.GetConnection()
            connection = DBConnUtil.GetConnection();
        }

        public bool CreatePolicy(Policy policy)
        {
            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "INSERT INTO Policy (PolicyId, PolicyName, CoverageAmount, Premium) VALUES (@Id, @Name, @Coverage, @Premium)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", policy.PolicyId);
                        cmd.Parameters.AddWithValue("@Name", policy.PolicyName);
                        cmd.Parameters.AddWithValue("@Coverage", policy.CoverageAmount);
                        cmd.Parameters.AddWithValue("@Premium", policy.Premium);

                        int result = cmd.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }


        public Policy GetPolicy(int policyId)
        {
            try
            {
                string query = "SELECT * FROM policy WHERE PolicyId = @PolicyId";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@PolicyId", policyId);
                    connection.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Policy
                            {
                                PolicyId = (int)reader["PolicyId"],
                                PolicyName = (string)reader["PolicyName"],
                                CoverageAmount = (decimal)reader["CoverageAmount"],
                                Premium = (decimal)reader["Premium"]
                            };
                        }
                    }
                    connection.Close();
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return null;
            }
        }

       

        public bool UpdatePolicy(Policy policy)
        {
            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "UPDATE Policy SET PolicyName = @Name, CoverageAmount = @Coverage, Premium = @Premium WHERE PolicyId = @Id";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", policy.PolicyName);
                        cmd.Parameters.AddWithValue("@Coverage", policy.CoverageAmount);
                        cmd.Parameters.AddWithValue("@Premium", policy.Premium);
                        cmd.Parameters.AddWithValue("@Id", policy.PolicyId);

                        int rows = cmd.ExecuteNonQuery();
                        return rows > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return false;
            }
        }

        public ICollection<Policy> GetAllPolicies()
        {
            List<Policy> policies = new List<Policy>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Policy";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Policy policy = new Policy
                            {
                                PolicyId = reader.GetInt32(0),
                                PolicyName = reader.GetString(1),
                                CoverageAmount = reader.GetDecimal(2),
                                Premium = reader.GetDecimal(3)
                            };
                            policies.Add(policy);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            return policies;
        }

        public bool DeletePolicy(int policyId)
        {
            try
            {
                string query = "DELETE FROM policy WHERE PolicyId = @PolicyId";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@PolicyId", policyId);

                    connection.Open();
                    int result = cmd.ExecuteNonQuery();
                    connection.Close();
                    return result > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        }
    }
}
