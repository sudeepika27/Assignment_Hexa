﻿public class Customer
{
    // Private fields
    private int customerId;
    private string customerName;
    private string email;
    private string phone;

    // Default constructor
    public Customer() { }

    // Parameterized constructor
    public Customer(int customerId, string customerName, string email, string phone)
    {
        this.customerId = customerId;
        this.customerName = customerName;
        this.email = email;
        this.phone = phone;
    }

    // Properties
    public int CustomerId
    {
        get { return customerId; }
        set { customerId = value; }
    }

    public string CustomerName
    {
        get { return customerName; }
        set { customerName = value; }
    }

    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    public string Phone
    {
        get { return phone; }
        set { phone = value; }
    }

    // Display method
    public void DisplayCustomerDetails()
    {
        Console.WriteLine("Customer ID   : " + CustomerId);
        Console.WriteLine("Name          : " + CustomerName);
        Console.WriteLine("Email         : " + Email);
        Console.WriteLine("Phone         : " + Phone);
    }
}
