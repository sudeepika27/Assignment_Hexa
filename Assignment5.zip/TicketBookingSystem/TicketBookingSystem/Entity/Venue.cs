﻿namespace TicketBookingSystemApp.bean
{
    public class Venue
    {
        // Private fields
        private int venueId;
        private string venueName;
        private string address;

        // Default constructor
        public Venue()
        {
        }

        // Parameterized constructor
        public Venue(int venueId, string venueName, string address)
        {
            this.venueId = venueId;
            this.venueName = venueName;
            this.address = address;
        }

        // Getter and Setter for VenueId
        public int VenueId
        {
            get { return venueId; }
            set { venueId = value; }
        }

        // Getter and Setter for VenueName
        public string VenueName
        {
            get { return venueName; }
            set { venueName = value; }
        }

        // Getter and Setter for Address
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string? Location { get; internal set; }
        public int Capacity { get; internal set; }

        // Display method
        public void DisplayVenueDetails()
        {
            Console.WriteLine("Venue ID     : " + VenueId);
            Console.WriteLine("Venue Name   : " + VenueName);
            Console.WriteLine("Address      : " + Address);
        }
    }
}
