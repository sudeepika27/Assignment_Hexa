﻿namespace TicketBookingSystemApp.bean
{
    public class Event
    {
        internal object VenueId;

        // Private fields
        private int eventId;
        private string eventName;
        private DateTime eventDate;
        private TimeSpan eventTime;
        private string venueName;
        private int totalSeats;
        private int availableSeats;
        private decimal ticketPrice;
        private string eventType; // "Movie", "Sports", "Concert"

        // Default constructor
        public Event()
        {
        }

        // Parameterized constructor
        public Event(int eventId, string eventName, DateTime eventDate, TimeSpan eventTime,
                     string venueName, int totalSeats, int availableSeats, decimal ticketPrice, string eventType)
        {
            this.eventId = eventId;
            this.eventName = eventName;
            this.eventDate = eventDate;
            this.eventTime = eventTime;
            this.venueName = venueName;
            this.totalSeats = totalSeats;
            this.availableSeats = availableSeats;
            this.ticketPrice = ticketPrice;
            this.eventType = eventType;
        }

        // Properties
        public int EventId
        {
            get { return eventId; }
            set { eventId = value; }
        }

        public string EventName
        {
            get { return eventName; }
            set { eventName = value; }
        }

        public DateTime EventDate
        {
            get { return eventDate; }
            set { eventDate = value; }
        }

        public TimeSpan EventTime
        {
            get { return eventTime; }
            set { eventTime = value; }
        }

        public string VenueName
        {
            get { return venueName; }
            set { venueName = value; }
        }

        public int TotalSeats
        {
            get { return totalSeats; }
            set { totalSeats = value; }
        }

        public int AvailableSeats
        {
            get { return availableSeats; }
            set { availableSeats = value; }
        }

        public decimal TicketPrice
        {
            get { return ticketPrice; }
            set { ticketPrice = value; }
        }

        public string EventType
        {
            get { return eventType; }
            set
            {
                if (value == "Movie" || value == "Sports" || value == "Concert")
                    eventType = value;
                else
                    throw new ArgumentException("Invalid event type. Must be 'Movie', 'Sports', or 'Concert'.");
            }
        }

        // Display method
        public void DisplayEventDetails()
        {
            Console.WriteLine("Event ID       : " + EventId);
            Console.WriteLine("Name           : " + EventName);
            Console.WriteLine("Date           : " + EventDate.ToShortDateString());
            Console.WriteLine("Time           : " + EventTime);
            Console.WriteLine("Venue          : " + VenueName);
            Console.WriteLine("Total Seats    : " + TotalSeats);
            Console.WriteLine("Available Seats: " + AvailableSeats);
            Console.WriteLine("Ticket Price   : " + TicketPrice.ToString("C"));
            Console.WriteLine("Type           : " + EventType);
        }
    }
}
