﻿namespace TicketBookingSystemApp.bean
{
    public class Booking
    {
        // Private fields
        private int bookingId;
        private int customerId;
        private int eventId;
        private DateTime bookingDate;
        private int numberOfTickets;
        private decimal totalAmount;

        // Default constructor
        public Booking()
        {
        }

        // Parameterized constructor
        public Booking(int bookingId, int customerId, int eventId, DateTime bookingDate, int numberOfTickets, decimal totalAmount)
        {
            this.bookingId = bookingId;
            this.customerId = customerId;
            this.eventId = eventId;
            this.bookingDate = bookingDate;
            this.numberOfTickets = numberOfTickets;
            this.totalAmount = totalAmount;
        }

        // Properties
        public int BookingId
        {
            get { return bookingId; }
            set { bookingId = value; }
        }

        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }

        public int EventId
        {
            get { return eventId; }
            set { eventId = value; }
        }

        public DateTime BookingDate
        {
            get { return bookingDate; }
            set { bookingDate = value; }
        }

        public int NumberOfTickets
        {
            get { return numberOfTickets; }
            set { numberOfTickets = value; }
        }

        public decimal TotalAmount
        {
            get { return totalAmount; }
            set { totalAmount = value; }
        }

        public object TotalPrice { get; internal set; }

        // Display method
        public void DisplayBookingDetails()
        {
            Console.WriteLine("Booking ID       : " + BookingId);
            Console.WriteLine("Customer ID      : " + CustomerId);
            Console.WriteLine("Event ID         : " + EventId);
            Console.WriteLine("Booking Date     : " + BookingDate.ToShortDateString());
            Console.WriteLine("No. of Tickets   : " + NumberOfTickets);
            Console.WriteLine("Total Amount     : $" + TotalAmount);
        }
    }
}
