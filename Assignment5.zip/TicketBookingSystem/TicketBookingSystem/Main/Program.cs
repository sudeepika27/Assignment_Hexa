﻿using Microsoft.Data.SqlClient;
using System;
using TicketBookingSystem.DAO;
//using TicketBookingSystem.Entity;
using TicketBookingSystem.Exception;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n====== Ticket Booking System Menu ======");
                Console.WriteLine("1. Add Venue");
                Console.WriteLine("2. Add Event");
                Console.WriteLine("3. Register Customer");
                Console.WriteLine("4. Book Ticket");
                Console.WriteLine("5. View Bookings");
                Console.WriteLine("6. Exit");
                Console.Write("Choose an option: ");

                switch (Console.ReadLine())
                {
                    case "1":
                        AddVenue();
                        break;
                    case "2":
                        AddEvent();
                        break;
                    case "3":
                        RegisterCustomer();
                        break;
                    case "4":
                        BookTicket();
                        break;
                    case "5":
                        ViewBookings();
                        break;
                    case "6":
                        exit = true;
                        Console.WriteLine("Exiting... Thank you!");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void AddVenue()
        {
            try
            {
                Console.Write("Enter Venue Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Location: ");
                string location = Console.ReadLine();

                Console.Write("Enter Capacity: ");
                int capacity = int.Parse(Console.ReadLine());

                Venue venue = new Venue { VenueName = name, Location = location, Capacity = capacity };

                VenueDAO dao = new VenueDAO();
                dao.AddVenue(venue);
                Console.WriteLine("Venue added successfully.");
            }
            catch (CustomException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void AddEvent()
        {
            try
            {
                Console.Write("Enter Event Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Event Date (yyyy-MM-dd): ");
                DateTime date = DateTime.Parse(Console.ReadLine());

                Console.Write("Enter Event Time (HH:mm): ");
                TimeSpan time = TimeSpan.Parse(Console.ReadLine());

                Console.Write("Enter Venue Id: ");
                int venueId = int.Parse(Console.ReadLine());

                Console.Write("Enter Total Seats: ");
                int totalSeats = int.Parse(Console.ReadLine());

                Console.Write("Enter Ticket Price: ");
                decimal price = decimal.Parse(Console.ReadLine());

                Console.Write("Enter Event Type (Movie, Sports, Concert): ");
                string type = Console.ReadLine();

                Event ev = new Event
                {
                    EventName = name,
                    EventDate = date,
                    EventTime = time,
                    VenueId = venueId,
                    TotalSeats = totalSeats,
                    AvailableSeats = totalSeats,
                    TicketPrice = price,
                    EventType = type
                };

                EventDAO dao = new EventDAO();
                dao.AddEvent(ev);
                Console.WriteLine("Event added successfully.");
            }
            catch (CustomException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void RegisterCustomer()
        {
            try
            {
                Console.Write("Enter Customer Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Email: ");
                string email = Console.ReadLine();

                Console.Write("Enter Phone: ");
                string phone = Console.ReadLine();

                Customer customer = new Customer {CustomerName = name, Email = email, Phone = phone };

                CustomerDAO dao = new CustomerDAO();
                dao.RegisterCustomer(customer);
                Console.WriteLine("Customer registered successfully.");
            }
            catch (CustomerNotFoundException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void BookTicket()
        {
            try
            {
                Console.Write("Enter Customer Id: ");
                int customerId = int.Parse(Console.ReadLine());

                Console.Write("Enter Event Id: ");
                int eventId = int.Parse(Console.ReadLine());

                Console.Write("Enter Number of Tickets: ");
                int numTickets = int.Parse(Console.ReadLine());

                Booking booking = new Booking
                {
                    CustomerId = customerId,
                    EventId = eventId,
                    NumberOfTickets = numTickets,
                    BookingDate = DateTime.Now
                };

                BookingDAO dao = new BookingDAO();
                dao.BookTicket(booking);
                Console.WriteLine("Tickets booked successfully.");
            }
            catch (CustomException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static void ViewBookings()
        {
            try
            {
                BookingDAO dao = new BookingDAO();
                var bookings = dao.GetAllBookings();

                Console.WriteLine("\n---- All Bookings ----");
                foreach (var booking in bookings)
                {
                    Console.WriteLine($"Booking Id: {booking.BookingId}, Customer Id: {booking.CustomerId}, Event Id: {booking.EventId}, Tickets: {booking.NumberOfTickets}, Date: {booking.BookingDate}");
                }
            }
            catch (CustomException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
