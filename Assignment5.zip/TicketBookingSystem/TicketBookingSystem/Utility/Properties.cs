﻿namespace TicketBookingSystem.Utility
{
    public static class Properties
    {
        public static string GetConnectionString()
        {
            // Hardcoded connection string (update if needed)
            return "Server=DESKTOP-TTFB49L;Database=TBSDB;Integrated Security=True;TrustServerCertificate=True";
        }
    }
}
