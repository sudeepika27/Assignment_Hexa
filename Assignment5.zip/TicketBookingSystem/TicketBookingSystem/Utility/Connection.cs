﻿using Microsoft.Data.SqlClient;
using System;

namespace TicketBookingSystem.Utility
{
    public static class Connection
    {
        private static SqlConnection connection = null;

        public static SqlConnection GetConnection()
        {
            if (connection == null || connection.State != System.Data.ConnectionState.Open)
            {
                // Direct connection string — update as needed
                string connectionString = "Server=DESKTOP-TTFB49L;Database=TBSDB;Integrated Security=True;TrustServerCertificate=True";
                connection = new SqlConnection(connectionString);
                connection.Open();
            }
            return connection;
        }

        public static void CloseConnection()
        {
            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}

