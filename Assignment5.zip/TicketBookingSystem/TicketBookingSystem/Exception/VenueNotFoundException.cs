﻿using System;

namespace TicketBookingSystem.Exception
{
    public class VenueNotFoundException : ApplicationException
    {
        public VenueNotFoundException(string message) : base(message)
        {
        }
    }
}
