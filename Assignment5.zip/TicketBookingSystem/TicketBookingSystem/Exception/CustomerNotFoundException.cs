﻿using System;

namespace TicketBookingSystem.Exception
{
    public class CustomerNotFoundException : ApplicationException
    {
        public CustomerNotFoundException(string message) : base(message)
        {
        }
    }
}
