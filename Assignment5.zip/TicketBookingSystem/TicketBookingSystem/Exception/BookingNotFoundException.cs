﻿using System;

namespace TicketBookingSystem.Exception
{
    public class BookingNotFoundException : ApplicationException
    {
        public BookingNotFoundException(string message) : base(message)
        {
        }
    }
}

