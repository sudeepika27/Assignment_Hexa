﻿using System;

namespace TicketBookingSystem.Exception
{
    public class InsufficientSeatsException : ApplicationException
    {
        public InsufficientSeatsException(string message) : base(message)
        {
        }
    }
}
