﻿using System;

namespace TicketBookingSystem.Exception
{
    public class EventNotFoundException : ApplicationException
    {
        public EventNotFoundException(string message) : base(message)
        {
        }
    }
}
