﻿using System;

namespace TicketBookingSystem.Exception
{
    public class DuplicateBookingException : ApplicationException
    {
        public DuplicateBookingException(string message) : base(message)
        {
        }
    }
}
