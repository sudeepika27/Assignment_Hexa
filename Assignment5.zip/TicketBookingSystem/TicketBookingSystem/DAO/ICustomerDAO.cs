﻿using System.Collections.Generic;
//using TicketBookingSystem.Entity;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public interface ICustomerDAO
    {
        void AddCustomer(Customer customer);
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(int customerId);
        Customer GetCustomerById(int customerId);
        List<Customer> GetAllCustomers();
    }
}
