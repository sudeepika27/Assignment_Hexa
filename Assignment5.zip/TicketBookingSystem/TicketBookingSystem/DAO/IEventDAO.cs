﻿using System.Collections.Generic;

using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public interface IEventDAO
    {
        void AddEvent(Event evnt);
        void UpdateEvent(Event evnt);
        void DeleteEvent(int eventId);
        Event GetEventById(int eventId);
        List<Event> GetAllEvents();
    }
}
