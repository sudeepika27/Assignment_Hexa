﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using TicketBookingSystem.@Exception; // corrected 'Exception' folder name
using TicketBookingSystem.Utility;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public class BookingDAO : IBookingDAO
    {
        public void AddBooking(Booking booking)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = @"INSERT INTO Booking 
                (CustomerId, EventId, NumberOfTickets, TotalAmount, BookingDate) 
                VALUES 
                (@customerId, @eventId, @numberOfTickets, @totalAmount, @bookingDate)";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@customerId", booking.CustomerId);
                cmd.Parameters.AddWithValue("@eventId", booking.EventId);
                cmd.Parameters.AddWithValue("@numberOfTickets", booking.NumberOfTickets);
                cmd.Parameters.AddWithValue("@totalAmount", booking.TotalAmount);
                cmd.Parameters.AddWithValue("@bookingDate", booking.BookingDate);
                cmd.ExecuteNonQuery();
            }
        }

        public void CancelBooking(int bookingId)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "DELETE FROM Booking WHERE BookingId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", bookingId);
                cmd.ExecuteNonQuery();
            }
        }

        public Booking GetBookingById(int bookingId)
        {
            Booking booking = null;
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Booking WHERE BookingId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", bookingId);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    booking = new Booking
                    {
                        BookingId = Convert.ToInt32(reader["BookingId"]),
                        CustomerId = Convert.ToInt32(reader["CustomerId"]),
                        EventId = Convert.ToInt32(reader["EventId"]),
                        NumberOfTickets = Convert.ToInt32(reader["NumberOfTickets"]),
                        TotalAmount = reader["TotalAmount"] != DBNull.Value ? Convert.ToDecimal(reader["TotalAmount"]) : 0m,

                        BookingDate = Convert.ToDateTime(reader["BookingDate"])
                    };
                }
                reader.Close();
            }
            return booking;
        }

        public List<Booking> GetBookingsByCustomer(int customerId)
        {
            List<Booking> bookings = new List<Booking>();
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Booking WHERE CustomerId = @customerId";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@customerId", customerId);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Booking booking = new Booking
                    {
                        BookingId = Convert.ToInt32(reader["BookingId"]),
                        CustomerId = Convert.ToInt32(reader["CustomerId"]),
                        EventId = Convert.ToInt32(reader["EventId"]),
                        NumberOfTickets = Convert.ToInt32(reader["NumberOfTickets"]),
                       // TotalAmount = Convert.ToDecimal(reader["TotalAmount"]),
                        TotalAmount = reader["TotalAmount"] != DBNull.Value ? Convert.ToDecimal(reader["TotalAmount"]) : 0m,

                        BookingDate = Convert.ToDateTime(reader["BookingDate"])
                    };
                    bookings.Add(booking);
                }
                reader.Close();
            }
            return bookings;
        }

        public void BookTicket(Booking booking)
        {
            try
            {
                using (SqlConnection conn = Connection.GetConnection())
                {
                    conn.Open(); // ✅ Now safe to open

                    string query = "INSERT INTO Booking (CustomerId, EventId, NumberOfTickets, TotalAmount, BookingDate) " +
                                   "VALUES (@CustomerId, @EventId, @NumberOfTickets, @TotalAmount, @BookingDate)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@CustomerId", booking.CustomerId);
                        cmd.Parameters.AddWithValue("@EventId", booking.EventId);
                        cmd.Parameters.AddWithValue("@NumberOfTickets", booking.NumberOfTickets);
                        cmd.Parameters.AddWithValue("@TotalAmount", booking.TotalAmount);
                        cmd.Parameters.AddWithValue("@BookingDate", DateTime.Now);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Tickets booked successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Ticket booking failed.");
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("SQL Error while booking ticket: " + ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }
        }

        public List<Booking> GetAllBookings()
        {
            List<Booking> bookings = new List<Booking>();
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Booking";
                SqlCommand cmd = new SqlCommand(query, connection);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Booking booking = new Booking
                    {
                        BookingId = Convert.ToInt32(reader["BookingId"]),
                        CustomerId = Convert.ToInt32(reader["CustomerId"]),
                        EventId = Convert.ToInt32(reader["EventId"]),
                        NumberOfTickets = Convert.ToInt32(reader["NumberOfTickets"]),
                        TotalAmount = reader["TotalAmount"] != DBNull.Value ? Convert.ToDecimal(reader["TotalAmount"]) : 0m,

                        BookingDate = Convert.ToDateTime(reader["BookingDate"])
                    };
                    bookings.Add(booking);
                }
                reader.Close();
            }
            return bookings;
        }
    }
}
