﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using TicketBookingSystem.Utility;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public class EventDAO : IEventDAO
    {
        public void AddEvent(Event evnt)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = @"INSERT INTO Event 
                    (EventName, EventDate, EventTime, VenueId, TotalSeats, AvailableSeats, TicketPrice, EventType)
                    VALUES (@name, @date, @time, @venueId, @totalSeats, @availableSeats, @price, @type)";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", evnt.EventName);
                cmd.Parameters.AddWithValue("@date", evnt.EventDate);
                cmd.Parameters.AddWithValue("@time", evnt.EventTime);
                cmd.Parameters.AddWithValue("@venueId", evnt.VenueId);
                cmd.Parameters.AddWithValue("@totalSeats", evnt.TotalSeats);
                cmd.Parameters.AddWithValue("@availableSeats", evnt.AvailableSeats);
                cmd.Parameters.AddWithValue("@price", evnt.TicketPrice);
                cmd.Parameters.AddWithValue("@type", evnt.EventType);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateEvent(Event evnt)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = @"UPDATE Event SET 
                    EventName = @name,
                    EventDate = @date,
                    EventTime = @time,
                    VenueId = @venueId,
                    TotalSeats = @totalSeats,
                    AvailableSeats = @availableSeats,
                    TicketPrice = @price,
                    EventType = @type
                    WHERE EventId = @id";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", evnt.EventName);
                cmd.Parameters.AddWithValue("@date", evnt.EventDate);
                cmd.Parameters.AddWithValue("@time", evnt.EventTime);
                cmd.Parameters.AddWithValue("@venueId", evnt.VenueId);
                cmd.Parameters.AddWithValue("@totalSeats", evnt.TotalSeats);
                cmd.Parameters.AddWithValue("@availableSeats", evnt.AvailableSeats);
                cmd.Parameters.AddWithValue("@price", evnt.TicketPrice);
                cmd.Parameters.AddWithValue("@type", evnt.EventType);
                cmd.Parameters.AddWithValue("@id", evnt.EventId);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteEvent(int eventId)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "DELETE FROM Event WHERE EventId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", eventId);
                cmd.ExecuteNonQuery();
            }
        }

        public Event GetEventById(int eventId)
        {
            Event evnt = null;
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Event WHERE EventId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", eventId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    evnt = new Event
                    {
                        EventId = Convert.ToInt32(reader["EventId"]),
                        EventName = reader["EventName"].ToString(),
                        EventDate = Convert.ToDateTime(reader["EventDate"]),
                        EventTime = TimeSpan.Parse(reader["EventTime"].ToString()),
                        VenueId = Convert.ToInt32(reader["VenueId"]),
                        TotalSeats = Convert.ToInt32(reader["TotalSeats"]),
                        AvailableSeats = Convert.ToInt32(reader["AvailableSeats"]),
                        TicketPrice = Convert.ToDecimal(reader["TicketPrice"]),
                        EventType = reader["EventType"].ToString()
                    };
                }
                reader.Close();
            }
            return evnt;
        }

        public List<Event> GetAllEvents()
        {
            List<Event> events = new List<Event>();
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Event";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Event evnt = new Event
                    {
                        EventId = Convert.ToInt32(reader["EventId"]),
                        EventName = reader["EventName"].ToString(),
                        EventDate = Convert.ToDateTime(reader["EventDate"]),
                        EventTime = TimeSpan.Parse(reader["EventTime"].ToString()),
                        VenueId = Convert.ToInt32(reader["VenueId"]),
                        TotalSeats = Convert.ToInt32(reader["TotalSeats"]),
                        AvailableSeats = Convert.ToInt32(reader["AvailableSeats"]),
                        TicketPrice = Convert.ToDecimal(reader["TicketPrice"]),
                        EventType = reader["EventType"].ToString()
                    };
                    events.Add(evnt);
                }
                reader.Close();
            }
            return events;
        }
    }
}
