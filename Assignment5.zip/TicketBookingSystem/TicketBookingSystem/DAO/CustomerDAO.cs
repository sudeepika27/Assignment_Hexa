﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using TicketBookingSystem.Utility;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public class CustomerDAO : ICustomerDAO
    {
        public void AddCustomer(Customer customer)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = @"INSERT INTO Customer 
                                (Name, Email, Phone) 
                                VALUES (@name, @email, @phone)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", customer.CustomerName);
                cmd.Parameters.AddWithValue("@email", customer.Email);
                cmd.Parameters.AddWithValue("@phone", customer.Phone);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateCustomer(Customer customer)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = @"UPDATE Customer SET 
                                Name = @name, 
                                Email = @email, 
                                Phone = @phone 
                                WHERE CustomerId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", customer.CustomerName);
                cmd.Parameters.AddWithValue("@email", customer.Email);
                cmd.Parameters.AddWithValue("@phone", customer.Phone);
                cmd.Parameters.AddWithValue("@id", customer.CustomerId);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteCustomer(int customerId)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "DELETE FROM Customer WHERE CustomerId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", customerId);
                cmd.ExecuteNonQuery();
            }
        }

        public Customer GetCustomerById(int customerId)
        {
            Customer customer = null;
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Customer WHERE CustomerId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", customerId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    customer = new Customer
                    {
                        CustomerId = Convert.ToInt32(reader["CustomerId"]),
                        CustomerName = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        Phone = reader["Phone"].ToString()
                    };
                }
                reader.Close();
            }
            return customer;
        }

        public void RegisterCustomer(Customer customer)
        {
            using (SqlConnection conn = Connection.GetConnection())
            {
                string query = "INSERT INTO Customer (Name, Email, Phone) VALUES (@Name, @Email, @Phone)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", customer.CustomerName);
                    cmd.Parameters.AddWithValue("@Email", customer.Email);
                    cmd.Parameters.AddWithValue("@Phone", customer.Phone);


                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        Console.WriteLine("Customer registered successfully.");
                    else
                        Console.WriteLine("Failed to register customer.");
                }
            }
        }


        public List<Customer> GetAllCustomers()
        {
            List<Customer> customers = new List<Customer>();
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Customer";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Customer customer = new Customer
                    {
                        CustomerId = Convert.ToInt32(reader["CustomerId"]),
                        CustomerName = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        Phone = reader["Phone"].ToString()
                    };
                    customers.Add(customer);
                }
                reader.Close();
            }
            return customers;
        }
    }
}
