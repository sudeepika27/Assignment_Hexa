﻿using System.Collections.Generic;
//using TicketBookingSystem.Entity;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public interface IBookingDAO
    {
        void AddBooking(Booking booking);
        void CancelBooking(int bookingId);
        Booking GetBookingById(int bookingId);
        List<Booking> GetBookingsByCustomer(int customerId);
        List<Booking> GetAllBookings();
    }
}
