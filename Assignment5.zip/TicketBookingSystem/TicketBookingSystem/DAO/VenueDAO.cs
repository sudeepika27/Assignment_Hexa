﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
//using TicketBookingSystem.Entity;
using TicketBookingSystem.Utility;
using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public class VenueDAO : IVenueDAO
    {
        public void AddVenue(Venue venue)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "INSERT INTO Venue (VenueName, Location, Capacity) VALUES (@name, @location, @capacity)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", venue.VenueName);
                command.Parameters.AddWithValue("@location", venue.Location);
                command.Parameters.AddWithValue("@capacity", venue.Capacity);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateVenue(Venue venue)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "UPDATE Venue SET VenueName = @name, Location = @location, Capacity = @capacity WHERE VenueId = @id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", venue.VenueName);
                command.Parameters.AddWithValue("@location", venue.Location);
                command.Parameters.AddWithValue("@capacity", venue.Capacity);
                command.Parameters.AddWithValue("@id", venue.VenueId);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteVenue(int venueId)
        {
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "DELETE FROM Venue WHERE VenueId = @id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", venueId);
                command.ExecuteNonQuery();
            }
        }

        public Venue GetVenueById(int venueId)
        {
            Venue? venue = null;
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Venue WHERE VenueId = @id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", venueId);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    venue = new Venue
                    {
                        VenueId = Convert.ToInt32(reader["VenueId"]),
                        VenueName = reader["VenueName"].ToString(),
                        Location = reader["Location"].ToString(),
                        Capacity = Convert.ToInt32(reader["Capacity"])
                    };
                }
                reader.Close();
            }
            return venue;
        }

        public List<Venue> GetAllVenues()
        {
            List<Venue> venues = new List<Venue>();
            using (SqlConnection connection = Connection.GetConnection())
            {
                string query = "SELECT * FROM Venue";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Venue venue = new Venue
                    {
                        VenueId = Convert.ToInt32(reader["VenueId"]),
                        VenueName = reader["VenueName"].ToString(),
                        Location = reader["Location"].ToString(),
                        Capacity = Convert.ToInt32(reader["Capacity"])
                    };
                    venues.Add(venue);
                }
                reader.Close();
            }
            return venues;
        }
    }
}
