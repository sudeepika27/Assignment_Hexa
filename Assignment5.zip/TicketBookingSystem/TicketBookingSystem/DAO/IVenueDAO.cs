﻿using TicketBookingSystemApp.bean;

namespace TicketBookingSystem.DAO
{
    public interface IVenueDAO
    {
        void AddVenue(Venue venue);
        void UpdateVenue(Venue venue);
        void DeleteVenue(int venueId);
        Venue GetVenueById(int venueId);
        List<Venue> GetAllVenues();
    }
}
