﻿namespace TechShop.Util
{
    public static class Properties
    {
        public static string GetConnectionString()
        {
            // Hardcoded connection string
            return "Server=DESKTOP-TTFB49L;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";
        }
    }
}
