﻿using Microsoft.Data.SqlClient;

namespace TransportManagementSystem.Utility
{
    public static class Connection
    {
        private static readonly string connectionString =
            "Server=DESKTOP-TTFB49L;Database=TransportManagementsys;Integrated Security=True;TrustServerCertificate=True";

        // Always return a NEW, unopened SqlConnection
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}