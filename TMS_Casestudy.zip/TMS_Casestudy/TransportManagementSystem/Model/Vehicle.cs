﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem.Model
{
    public class Vehicle

    {
        public int VehicleID { get; set; }
        public string? Model { get; set; }
        public double Capacity { get; set; }
        public string? Type { get; set; }
        public string? Status { get; set; }

        // Default constructor
        public Vehicle() { }

        // Parameterized constructor (without ID)
        public Vehicle(string model, double capacity, string type, string status)
        {
            Model = model;
            Capacity = capacity;
            Type = type;
            Status = status;
        }

        // Parameterized constructor (with ID)
        public Vehicle(int vehicleID, string model, double capacity, string type, string status)
        {
            VehicleID = vehicleID;
            Model = model;
            Capacity = capacity;
            Type = type;
            Status = status;
        }

        public override string ToString()
        {
            return $"Vehicle [vehicleID={VehicleID}, model={Model}, capacity={Capacity}, type={Type}, status={Status}]";
        }

    }
}