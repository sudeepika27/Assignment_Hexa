﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem.Model
{
    public class Driver
    {
        public int DriverID { get; set; }        // Unique identifier for the driver
        public string? FirstName { get; set; }   // Driver's first name
        public string? LicenseNumber { get; set; } // Driver's license number
        public string? Status { get; set; }      // Driver status: Available, Allocated, etc.

        // Default constructor
        public Driver() { }

        // Parameterized constructor
        public Driver(int driverID, string firstName, string licenseNumber, string status)
        {
            DriverID = driverID;
            FirstName = firstName;
            LicenseNumber = licenseNumber;
            Status = status;
        }

        public override string ToString()
        {
            return $"Driver [DriverID={DriverID}, FirstName={FirstName}, LicenseNumber={LicenseNumber}, Status={Status}]";
        }
    }
}
