﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem.Model
{
    public class Route
    {
        public int RouteID { get; set; }
        public string? StartDestination { get; set; }
        public string? EndDestination { get; set; }
        public double Distance { get; set; }

        // Default constructor
        public Route() { }

        // Parameterized constructor
        public Route(int routeID, string startDestination, string endDestination, double distance)
        {
            RouteID = routeID;
            StartDestination = startDestination;
            EndDestination = endDestination;
            Distance = distance;
        }

        public override string ToString()
        {
            return $"Route [RouteID={RouteID}, StartDestination={StartDestination}, EndDestination={EndDestination}, Distance={Distance}]";
        }
    }

}