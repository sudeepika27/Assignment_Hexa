﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.SqlClient;
using TransportManagementSystem.Model;
using TransportManagementSystem.My_exceptions;
using TransportManagementSystem.Utility;

namespace TransportManagementSystem.DAO
{
    public class TransportDAO : ITransportManagementService
    {
        private readonly List<Vehicle> vehicles = new();
        private readonly List<Booking> bookings = new();
        private readonly List<Trip> trips = new();
        private readonly List<Driver> drivers = new();

        private SqlConnection GetOpenConnection()
        {
            var conn = Connection.GetConnection();
            conn.Open();
            return conn;
        }

        public bool AddVehicle(Vehicle vehicle)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = "INSERT INTO Vehicles (Model, Capacity, Type, Status) VALUES (@model, @capacity, @type, @status)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@model", vehicle.Model);
                        cmd.Parameters.AddWithValue("@capacity", vehicle.Capacity);
                        cmd.Parameters.AddWithValue("@type", vehicle.Type);
                        cmd.Parameters.AddWithValue("@status", vehicle.Status);

                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool UpdateVehicle(Vehicle vehicle)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = @"UPDATE Vehicles SET Model = @model, Capacity = @capacity, Type = @type, Status = @status WHERE VehicleID = @vehicleId";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@model", vehicle.Model);
                        cmd.Parameters.AddWithValue("@capacity", vehicle.Capacity);
                        cmd.Parameters.AddWithValue("@type", vehicle.Type);
                        cmd.Parameters.AddWithValue("@status", vehicle.Status);
                        cmd.Parameters.AddWithValue("@vehicleId", vehicle.VehicleID);

                        if (cmd.ExecuteNonQuery() == 0)
                            throw new VehicleNotFoundException("Vehicle not found");

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool DeleteVehicle(int vehicleId)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = "DELETE FROM Vehicles WHERE VehicleID = @vehicleId";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@vehicleId", vehicleId);

                        if (cmd.ExecuteNonQuery() == 0)
                            throw new VehicleNotFoundException("Vehicle not found");

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool ScheduleTrip(int vehicleID, int routeID, string departureDate, string arrivalDate)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = @"INSERT INTO Trips (VehicleID, RouteID, DepartureDate, ArrivalDate, Status, TripType, MaxPassengers)
                                     VALUES (@VehicleID, @RouteID, @DepartureDate, @ArrivalDate, 'Scheduled', 'Passenger', 50)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@VehicleID", vehicleID);
                        cmd.Parameters.AddWithValue("@RouteID", routeID);
                        cmd.Parameters.AddWithValue("@DepartureDate", DateTime.Parse(departureDate));
                        cmd.Parameters.AddWithValue("@ArrivalDate", DateTime.Parse(arrivalDate));

                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool CancelTrip(int tripID)
        {
            try
            {
                var trip = trips.FirstOrDefault(t => t.TripID == tripID);
                if (trip == null) throw new Exception("Trip not found");
                trip.Status = "Cancelled";
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool BookTrip(int tripId, int passengerId, string bookingDate)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = @"INSERT INTO Bookings (TripID, PassengerID, BookingDate, Status) 
                                     VALUES (@TripID, @PassengerID, @BookingDate, 'Confirmed')";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@TripID", tripId);
                        cmd.Parameters.AddWithValue("@PassengerID", passengerId);
                        cmd.Parameters.AddWithValue("@BookingDate", DateTime.Parse(bookingDate));

                        return cmd.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool CancelBooking(int bookingId)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string checkQuery = "SELECT COUNT(*) FROM Bookings WHERE BookingID = @BookingID";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@BookingID", bookingId);
                        if ((int)checkCmd.ExecuteScalar() == 0)
                            throw new BookingNotFoundException("Booking not found");
                    }

                    string updateQuery = "UPDATE Bookings SET Status = 'Cancelled' WHERE BookingID = @BookingID";
                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        updateCmd.Parameters.AddWithValue("@BookingID", bookingId);
                        return updateCmd.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool AllocateDriver(int tripId, int driverId)
        {
            try
            {
                using (SqlConnection conn = GetOpenConnection())
                {
                    string checkDriverQuery = "SELECT Status FROM Drivers WHERE DriverID = @DriverID";
                    using (SqlCommand checkCmd = new SqlCommand(checkDriverQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@DriverID", driverId);
                        var status = checkCmd.ExecuteScalar()?.ToString();
                        if (status == null || status == "Assigned")
                            return false;
                    }

                    string updateTripQuery = "UPDATE Trips SET DriverID = @DriverID WHERE TripID = @TripID";
                    using (SqlCommand updateTripCmd = new SqlCommand(updateTripQuery, conn))
                    {
                        updateTripCmd.Parameters.AddWithValue("@DriverID", driverId);
                        updateTripCmd.Parameters.AddWithValue("@TripID", tripId);
                        if (updateTripCmd.ExecuteNonQuery() == 0)
                            return false;
                    }

                    string updateDriverQuery = "UPDATE Drivers SET Status = 'On Trip' WHERE DriverID = @DriverID";
                    using (SqlCommand updateDriverCmd = new SqlCommand(updateDriverQuery, conn))
                    {
                        updateDriverCmd.Parameters.AddWithValue("@DriverID", driverId);
                        updateDriverCmd.ExecuteNonQuery();
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public bool DeallocateDriver(int tripId)
        {
            try
            {
                var driver = drivers.FirstOrDefault(d => d.Status == "Assigned");
                if (driver == null) return false;

                driver.Status = "Available";
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<Booking> GetBookingsByPassenger(int passengerID)
        {
            try
            {
                List<Booking> bookingsList = new();
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = "SELECT * FROM Bookings WHERE PassengerID = @PassengerID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@PassengerID", passengerID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookingsList.Add(new Booking
                                {
                                    BookingID = (int)reader["BookingID"],
                                    PassengerID = (int)reader["PassengerID"],
                                    TripID = (int)reader["TripID"],
                                    Status = reader["Status"].ToString(),
                                });
                            }
                        }
                    }
                }
                return bookingsList;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<Driver> GetAvailableDrivers()
        {
            try
            {
                List<Driver> availableDrivers = new();
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = "SELECT * FROM Drivers WHERE Status = 'Available'";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                availableDrivers.Add(new Driver
                                {
                                    DriverID = (int)reader["DriverID"],
                                    FirstName = reader["FirstName"].ToString(),
                                    Status = reader["Status"].ToString(),
                                });
                            }
                        }
                    }
                }
                return availableDrivers;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<Booking> GetBookingsByTrip(int tripID)
        {
            try
            {
                List<Booking> bookingsList = new();
                using (SqlConnection conn = GetOpenConnection())
                {
                    string query = "SELECT * FROM Bookings WHERE TripID = @TripID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@TripID", tripID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bookingsList.Add(new Booking
                                {
                                    BookingID = (int)reader["BookingID"],
                                    PassengerID = (int)reader["PassengerID"],
                                    TripID = (int)reader["TripID"],
                                    Status = reader["Status"].ToString(),
                                });
                            }
                        }
                    }
                }
                return bookingsList;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
