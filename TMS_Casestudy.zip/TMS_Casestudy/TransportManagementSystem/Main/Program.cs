﻿using TransportManagementSystem.DAO;
using TransportManagementSystem.Model;
using System;
using TransportManagementSystem.My_exceptions;

namespace TransportManagementSystem
{
    class Program
    {
        public static void Main(string[] args)
        {
            TransportDAO service = new TransportDAO();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n--- Transport Management System ---");
                Console.WriteLine("1. Add Vehicle");
                Console.WriteLine("2. Update Vehicle");
                Console.WriteLine("3. Delete Vehicle");
                Console.WriteLine("4. Schedule Trip");
                Console.WriteLine("5. Allocate Driver");
                Console.WriteLine("6. Book Trip");
                Console.WriteLine("7. Cancel Booking");
                Console.WriteLine("8. View All Bookings");
                Console.WriteLine("9. View All Trips");
                Console.WriteLine("10. View All Available Drivers");
                Console.WriteLine("11. Exit");
                Console.Write("Choose an option: ");
                string? choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            Console.Write("Enter Model: ");
                            string? model = Console.ReadLine();
                            Console.Write("Enter Capacity: ");
                            double capacity = double.Parse(Console.ReadLine()!);
                            Console.Write("Enter Type: ");
                            string? type = Console.ReadLine();
                            Console.Write("Enter Status: ");
                            string? status = Console.ReadLine();

                            Vehicle vehicle = new Vehicle(model!, capacity, type!, status!);
                            if (service.AddVehicle(vehicle))
                                Console.WriteLine("Vehicle added successfully!");
                            break;

                        case "2":
                            Console.Write("Enter Vehicle ID: ");
                            int updateId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter New Model: ");
                            string? newModel = Console.ReadLine();
                            Console.Write("Enter New Capacity: ");
                            double newCapacity = double.Parse(Console.ReadLine()!);
                            Console.Write("Enter New Type: ");
                            string? newType = Console.ReadLine();
                            Console.Write("Enter New Status: ");
                            string? newStatus = Console.ReadLine();

                            Vehicle updatedVehicle = new Vehicle(updateId, newModel!, newCapacity, newType!, newStatus!);
                            service.UpdateVehicle(updatedVehicle);
                            Console.WriteLine("Vehicle updated successfully!");
                            break;

                        case "3":
                            Console.Write("Enter Vehicle ID to delete: ");
                            int deleteId = int.Parse(Console.ReadLine()!);
                            service.DeleteVehicle(deleteId);
                            Console.WriteLine("Vehicle deleted successfully!");
                            break;

                        case "4":
                            Console.Write("Enter Vehicle ID: ");
                            int vId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter Route ID: ");
                            int rId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter Departure Date (yyyy-MM-dd): ");
                            string? depDate = Console.ReadLine();
                            Console.Write("Enter Arrival Date (yyyy-MM-dd): ");
                            string? arrDate = Console.ReadLine();


                            if (service.ScheduleTrip(vId, rId, depDate!, arrDate!))
                                Console.WriteLine("Trip scheduled successfully!");
                            break;

                        case "5":
                            Console.Write("Enter Trip ID: ");
                            int tripId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter Driver ID: ");
                            int driverId = int.Parse(Console.ReadLine()!);

                            if (service.AllocateDriver(tripId, driverId))
                                Console.WriteLine("Driver allocated successfully!");
                            else
                                Console.WriteLine("Driver allocation failed.");
                            break;

                        case "6":
                            Console.Write("Enter Trip ID: ");
                            int bookTripId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter Passenger ID: ");
                            int passengerId = int.Parse(Console.ReadLine()!);
                            Console.Write("Enter Booking Date (yyyy-MM-dd): ");
                            string? bookDate = Console.ReadLine();

                            if (service.BookTrip(bookTripId, passengerId, bookDate!))
                                Console.WriteLine("Trip booked successfully!");
                            else
                                Console.WriteLine("Booking failed.");
                            break;

                        case "7":
                            Console.Write("Enter Booking ID to cancel: ");
                            int cancelId = int.Parse(Console.ReadLine()!);
                            service.CancelBooking(cancelId);
                            Console.WriteLine("Booking canceled successfully!");
                            break;
                        case "8":
                            Console.WriteLine("Enter Passenger ID to fetch bookings:");
                            int passengerID = int.Parse(Console.ReadLine()!);  // Get the Passenger ID from user input
                            Console.WriteLine($"Bookings for Passenger ID {passengerID}:");
                            foreach (var b in service.GetBookingsByPassenger(passengerID))  // Fetch bookings for the given passenger
                            {
                                Console.WriteLine($"Booking ID: {b.BookingID}, Trip ID: {b.TripID}, Status: {b.Status}");
                            }
                            break;

                        case "9":

                            Console.WriteLine("Enter Trip ID to fetch bookings:");
                            int tripID = int.Parse(Console.ReadLine()!);  // Get the Trip ID from user input

                            var bookings = service.GetBookingsByTrip(tripID);  // Fetch bookings for the given trip

                            if (bookings == null || bookings.Count == 0)
                            {
                                Console.WriteLine($" No bookings found for Trip ID {tripID}.");
                            }
                            else
                            {
                                Console.WriteLine($"Bookings for Trip ID {tripID}:");
                                foreach (var b in bookings)
                                {
                                    Console.WriteLine($"Booking ID: {b.BookingID}, Passenger ID: {b.PassengerID}, Status: {b.Status}");
                                }
                            }
                            break;

                       
                        case "10":
                            Console.WriteLine("Available Drivers:");
                            foreach (var d in service.GetAvailableDrivers())  // Fetch all available drivers
                            {
                                Console.WriteLine($"Driver ID: {d.DriverID}, FirstName: {d.FirstName}, Status: {d.Status}");
                            }
                            break;


                        case "11":
                            exit = true;
                            break;

                        default:
                            Console.WriteLine("Invalid option. Try again.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }

            Console.WriteLine("Exiting Transport Management System. Goodbye!");
        }
    }
}
