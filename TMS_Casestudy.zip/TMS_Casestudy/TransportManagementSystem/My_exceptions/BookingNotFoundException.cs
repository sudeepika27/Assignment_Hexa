﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem.My_exceptions
{
    public class BookingNotFoundException : Exception
    {

        public BookingNotFoundException() { }

        public BookingNotFoundException(string message)
            : base(message) { }

        public BookingNotFoundException(string message, Exception inner)
            : base(message, inner) { }
    }
}