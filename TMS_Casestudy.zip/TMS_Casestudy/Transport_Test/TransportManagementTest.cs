using NUnit.Framework;
using System;
using TransportManagementSystem.DAO;
using TransportManagementSystem.Model;


namespace TransportManagementSystem.Tests
{
    [TestFixture]
    public class TransportManagementSystemTests
    {
        private TransportDAO system;

        [SetUp]
        public void Setup()
        {
            system = new TransportDAO();
        }

        // 1. Test case: Driver mapped to trip (vehicle) successfully
        [Test]
        public void AllocateDriver_ShouldAssignDriver_WhenAvailable()
        {
            var result = system.AllocateDriver(tripId: 1, driverId: 1); // Ensure these IDs exist
            Assert.That(result, Is.True, "Driver should be assigned to the trip successfully.");
        }

        // 2. Test case: Vehicle added successfully
        [Test]
        public void AddVehicle_ShouldReturnTrue_WhenVehicleIsValid()
        {
            var vehicle = new Vehicle
            {
                Model = "Ashok Leyland",
                Capacity = 50,
                Type = "Truck",
                Status = "Available"
            };

            try
            {
                var result = system.AddVehicle(vehicle);
                Assert.That(result, Is.True, "Vehicle should be added successfully.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"AddVehicle threw an exception: {ex.Message}");
            }
        }

        // 3. Test case: Booking successfully created
        [Test]
        public void BookTrip_ShouldReturnTrue_WhenTripAndPassengerExist()
        {
            try
            {
                // Make sure tripId = 1 and passengerId = 101 exist in your database
                // Otherwise, insert dummy trip and passenger data before running this test

                var bookingDate = DateTime.Now.ToString("yyyy-MM-dd");

                var result = system.BookTrip(
                    tripId: 1,
                    passengerId: 5,
                    bookingDate: bookingDate);

                Assert.That(result, Is.True, "Booking should be created successfully.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"BookTrip threw an exception: {ex.Message}");
            }
        }


        // 4. Test case: Exception thrown when vehicle or booking not found
        [Test]
        public void CancelBooking_ShouldThrowBookingNotFoundException_WhenInvalidId()
        {
            var ex = Assert.Throws<My_exceptions.BookingNotFoundException>(() =>
                system.CancelBooking(bookingId: -1)); // Invalid ID
            Assert.That(ex.Message, Is.EqualTo("Booking not found"));
        }
    }
}

