﻿namespace SIS.Utility
{
    public static class Properties
    {
        public static string GetConnectionString()
        {
            // Make sure the DB name and server are correct
            return "Server=DESKTOP-TTFB49L;Database=SISDB;Integrated Security=True;TrustServerCertificate=True";
        }
    }
}
